import React, { useState, useContext } from "react";
import IconButton from "@mui/material/IconButton";
import DeleteIcon from "@mui/icons-material/Delete";
import "./todo.css";
import { TextField, ThemeProvider, Typography } from "@mui/material";
import Button from "@mui/material/Button";
import createTheme from "@mui/material";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import Checkbox from "@mui/material/Checkbox";
import { blue } from "@mui/material/colors";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import { CenterFocusStrong, CheckBox } from "@mui/icons-material";
import { TodoContext } from "../../state/todocontext";
import { TodoActions } from "../../state/todoreducer";

export const Todo = () => {
  const [input, setInput] = useState("");
  const [todoState, todoDispatch] = useContext(TodoContext);
  {
    /*const [oldTodos, setToDos] = useState([]);*/
  }
  const onInput = (event) => {
    console.log(event.target.value);
    setInput(event.target.value);
  };
  const addTodo = () => {
    todoDispatch({
      type: TodoActions.ADD,
      todo: { title: input, isComplete: false },
    });
    setInput("");
  };
  const toggleChecked = (todo) => {
    todoDispatch({
      type: TodoActions.TOGGLE,
      todo,
    });
  };
  const label = { inputProps: { "aria-label": "Checkbox demo" } };
  // const newTodos = [...oldTodos];
  // const updatedTodo = newTodos.find((x) => x.title === todo.title);
  // updatedTodo.isComplete = !todo.isComplete;
  // setToDos(newTodos);
  // };

  const deleteTodo = (todo) => {
    todoDispatch({
      type: TodoActions.DELETE,
      todo,
    });
  };

  return (
    <>
      <div class="display">
        Todo
        <TextField
          id="standard-basic"
          label="EnterTask"
          defaultValue="Enter a Task:"
          variant="standard"
          onInput={onInput}
          value={input}
          color="secondary"
        />
        <Button
          variant="text"
          sx={{
            borderRadius: 70,
          }}
          onClick={addTodo}
        >
          Add
        </Button>
        {todoState.todos.map((todo, index) => (
          <p key={index} index={index} deleteTodo={deleteTodo} draggable>
            {/* <p key={todo.title}> */}

            <CheckBox
              {...label}
              icon={<CheckCircleOutlineIcon />}
              checkedIcon={<CheckCircleIcon />}
              checked={todo.isComplete}
              onChange={() => toggleChecked(todo)}
              sx={{
                color: blue[800],
                "&.Mui-checked": {
                  color: blue[600],
                },
              }}
            />

            <IconButton
              onClick={() => deleteTodo(index)}
              edge="start"
              color="primary"
            >
              <DeleteOutlineIcon />
            </IconButton>

            {todo.title}
          </p>
        ))}
      </div>
    </>
  );
};
